The XA-USBA-LED folder contains the design data for the XR-USB-AUDIO-2.0-MC LED bar add On.

The CAD software used was Mentor Graphics DxDesigner as part of the Mentor Graphics PADS flow (2007.4).