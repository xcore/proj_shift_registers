README.txt
----------

Additional information relating to the build of design XPCB-039.

Design Ref : PROVOLONE-1V0 (XPCB-039)

Contact : Corin Rathbone
Tel(UK) : 0117 9154225
Email   : corin@xmos.com
Address : XMOS Limited
          Venturers House
          King Street
          Bristol
          United Kingdom
          BS1 4PB

PCB Design tool : Mentor Graphics PADS9.2 Flow. DxDesigner, PADS Layout.


Description of files included in XPCB-039-FAB.zip:

./README.txt    This file.

./BOM/      This directory contains the bill of materials and component position files for fabrication.

XPCB-039.pos        Component Position Data
XPCB-039.xls        Bill Of Materials

./Gerber/       This directory contains the following gerber files for the design in RS-274-X format.
      
XPCB-039-Ln.pho     PCB Copper Layer (where n = layer number, 01=Top Side)
XPCB-039-SST.pho    Silkscreen Top
XPCB-039-SSB.pho    Silkscreen Bottom  
XPCB-039-SMT.pho    Solder Mask Top
XPCB-039-SMB.pho    Solder Mask Bottom
XPCB-039-SPT.pho    Solder Paste Top
XPCB-039-SPB.pho    Solder Paste Bottom
XPCB-039-FAB.pho    Fabrication Instructions
XPCB-039-DRL.pho    Drill Diagram

./Drill/        This directory contains the following drill data files for the design.

XPCB-039-NC.drl     NC Drill File (Excellon Format, metric (000.00), suppress trailing zeros, absolute coordinates)
XPCB-039-NC.rep     NC Drill Report (Sizes & Quantities)
XPCB-039-NC.lst     NC Drill List (Sizes & Coordinates)

./Netlist/      This directory contains the netlist files for equivalence checking and bare board test.

XPCB-039-IPC.net    IPC-D-356 Format Netlist
